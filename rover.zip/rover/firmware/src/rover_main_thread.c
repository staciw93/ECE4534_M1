#include "rover_main_thread.h"
#include "debug.h"
#include "sensor_queue.h"

enum MainStates mainState;

/*******************************************************************************
  Function:
    void ROVER_MAIN_THREAD_Initialize ( void )

  Remarks:
    See prototype in rover_main_thread.h.
 */

void ROVER_MAIN_THREAD_Initialize ( void )
{
    dbgOutputEvent(MAIN_THREAD_INIT);
    
    /* Set up GPIO port for debugging */
    PLIB_PORTS_DirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_E, 0x00FF);
    PLIB_PORTS_DirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_B, 0x3800);
    PLIB_PORTS_DirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_G, 0x0100);
    PLIB_PORTS_DirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_A, 0x0400);
    PLIB_PORTS_DirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_D, 0x0940);
    
    createQueues();
    
    mainState = SEND_MAIN;
}

void sendMsgToTXISR(struct MsgData msg){
    writeToTXQueue("s");
    writeToTXQueue("e");
    writeToTXQueue("n");
    writeToTXQueue("t");
    writeToTXQueue(":");
    writeToTXQueue("R");
    
    // write message to queue
    writeToTXQueue("t");
    writeToTXQueue("y");
    writeToTXQueue("p");
    writeToTXQueue("e");
    writeToTXQueue(":");
    
    uint8_t val = msg.label;
    writeToTXQueue(&val);
    
    writeToTXQueue("f");
    writeToTXQueue("i");
    writeToTXQueue("n");
    
    // enable transmit interrupts
    SYS_INT_SourceEnable(INT_SOURCE_USART_1_TRANSMIT);
}

/******************************************************************************
  Function:
    void ROVER_MAIN_THREAD_Tasks ( void )

  Remarks:
    See prototype in rover_main_thread.h.
 */

void ROVER_MAIN_THREAD_Tasks ( void )
{
    dbgOutputEvent(MAIN_THREAD_START);
    
    switch(mainState){
        case SEND_MAIN:{
            struct MsgData m;
            m.label = SENSOR;
            sendMsgToTXISR(m);
            dbgOutputEvent(SENT_MSG_TO_TX_Q);
            mainState = REC_MAIN;
            break;
        }
        case REC_MAIN:{
            struct MsgData mr;
            readFromSensorQueue(&mr);
            if(mr.label == SENSOR){
                dbgOutputEvent(REC_MSG_FROM_SENSOR_Q );
                mainState = SEND_MAIN;
            }
            break;
        }
        default:{
            break;
        }
    }
}

 

/*******************************************************************************
 End of File
 */
