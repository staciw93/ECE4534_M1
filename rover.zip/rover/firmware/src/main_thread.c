#include "main_thread.h"
#include "debug.h"
#include "sensor_queue.h"

/*******************************************************************************
  Function:
    void MAIN_THREAD_Initialize ( void )

  Remarks:
    See prototype in main_thread.h.
 */

void MAIN_THREAD_Initialize ( void )
{
    dbgOutputEvent(MAIN_THREAD_INIT);
    
    /* Set up GPIO port for debugging */
    PLIB_PORTS_DirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_E, 0x00FF);
    PLIB_PORTS_DirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_B, 0x3800);
    PLIB_PORTS_DirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_G, 0x0100);
    PLIB_PORTS_DirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_A, 0x0400);
    PLIB_PORTS_DirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_D, 0x0940);
    
    /* Create the message queues */
    createQueues();
    
    mainState = REC_FROM_SENSOR_Q;
}

void sendMsgToTXISR(struct MsgData msg){
    writeToTXQueue("s");
    writeToTXQueue("e");
    writeToTXQueue("n");
    writeToTXQueue("t");
    writeToTXQueue(":");
    writeToTXQueue("R");
    // write message to queue
    writeToTXQueue("t");
    writeToTXQueue("y");
    writeToTXQueue("p");
    writeToTXQueue("e");
    writeToTXQueue(":");
    
    uint8_t val = msg.label;
    writeToTXQueue(&val);
    
    writeToTXQueue("f");
    writeToTXQueue("i");
    writeToTXQueue("n");
    
    // enable transmit interrupts
    SYS_INT_SourceEnable(INT_SOURCE_USART_1_TRANSMIT);
}

/******************************************************************************
  Function:
    void MAIN_THREAD_Tasks ( void )

  Remarks:
    See prototype in main_thread.h.
 */

void MAIN_THREAD_Tasks ( void )
{
    dbgOutputEvent(MAIN_THREAD_START);
    
    struct MsgData mr;
    
    /* Check the application's current state. */
    switch ( mainState )
    {
        case REC_FROM_SENSOR_Q:{
            if(uxQueueMessagesWaiting(sensorMQ) != 0){
                readFromSensorQueue(&mr);
                dbgOutputEvent(REC_MSG_FROM_SENSOR_Q);
                dbgOutputVal(mr.label);
                if(mr.label == SENSOR)
                    mainState = SEND_TO_TX_Q;
                else if(mr.label == MOTOR)
                    mainState = SEND_TO_MOTOR_Q;
            }
            break;
        }
        case SEND_TO_TX_Q:{
            sendMsgToTXISR(mr);
            dbgOutputEvent(SENT_MSG_TO_TX_Q);
            mainState = REC_FROM_SENSOR_Q;
            break;
        }
        case SEND_TO_MOTOR_Q:{
            writeToMotorQueue(&mr);
            dbgOutputEvent(SENT_MSG_TO_MOTOR_Q);
            mainState = REC_FROM_SENSOR_Q;
            break;
        }
        case STOP_MAIN:{
            break;
        }
        default:{
            break;
        }
    }
}

 

/*******************************************************************************
 End of File
 */
