#include "motor_thread.h"
#include "debug.h"
#include "sensor_queue.h"

/*******************************************************************************
  Function:
    void MOTOR_THREAD_Initialize ( void )

  Remarks:
    See prototype in motor_thread.h.
 */

void MOTOR_THREAD_Initialize ( void )
{
    dbgOutputEvent(MOTOR_THREAD_INIT);
    
    motorState = REC_FROM_MOTOR_Q;
}


/******************************************************************************
  Function:
    void MOTOR_THREAD_Tasks ( void )

  Remarks:
    See prototype in motor_thread.h.
 */

void MOTOR_THREAD_Tasks ( void )
{
    dbgOutputEvent(MOTOR_THREAD_START);
    
    struct MsgData m;
    
    /* Check the application's current state. */
    switch ( motorState )
    {
        case REC_FROM_MOTOR_Q:{
            if(uxQueueMessagesWaiting(motorMQ) != 0){
                readFromMotorQueue(&m);
                dbgOutputEvent(REC_MSG_FROM_MOTOR_Q);
                m.label = MSG_REC;
                dbgOutputVal(m.label);
            }
            break;
        }
        case STOP_MOTOR:{
            break;
        }
        default:{
            break;
        }
    }
}

 

/*******************************************************************************
 End of File
 */
