#ifndef _DEBUG_H    /* Guard against multiple inclusion */
#define _DEBUG_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "system_config.h"
#include "system_definitions.h"

/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif  
    
#define SENT_MSG_TO_TX_Q                0x30
#define SENT_MSG_TO_DATA_Q              0x31
#define SENT_MSG_TO_MOTOR_Q             0x32
#define SENT_MSG_TO_SENSOR_Q            0x33
#define REC_MSG_FROM_TX_Q               0x34
#define REC_MSG_FROM_DATA_Q             0x35
#define REC_MSG_FROM_MOTOR_Q            0x36
#define REC_MSG_FROM_SENSOR_Q           0x37

#define UART_ISR_START                  0x50
#define UART_ISR_STOP                   0x51
#define LINE_ISR_START                  0x52
#define LINE_ISR_STOP                   0x53
#define RGB_ISR_START                   0x54
#define RGB_ISR_STOP                    0x55
#define ENCODER_ISR_START               0x56
#define ENCODER_ISR_STOP                0x57
    
#define MESSAGE_RECEIVE                 0x60
#define MESSAGE_WRITE_SUCCESS           0x61
    
#define ERR_TX_QUEUE_NOT_CREATED        0x40
#define ERR_DATA_QUEUE_NOT_CREATED      0x41
#define ERR_MOTOR_QUEUE_NOT_CREATED     0x42
#define ERR_SENSOR_QUEUE_NOT_CREATED    0x43
#define ERR_MESSAGE_WRITE_FAIL          0x44
#define ERR_HANDLER_CALLED              0x45

    
void dbgOutputVal(uint8_t outVal);
void dbgOutputEvent(unsigned int outVal);
void stopBadError();

    

    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
