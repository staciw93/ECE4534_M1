#include "debug.h"

void dbgOutputVal(uint8_t outVal){
    PLIB_PORTS_PinWrite (PORTS_ID_0, PORT_CHANNEL_B, PORTS_BIT_POS_11, outVal&0x01);
    PLIB_PORTS_PinWrite (PORTS_ID_0, PORT_CHANNEL_B, PORTS_BIT_POS_13, outVal&0x02);
    PLIB_PORTS_PinWrite (PORTS_ID_0, PORT_CHANNEL_B, PORTS_BIT_POS_12, outVal&0x04);
    PLIB_PORTS_PinWrite (PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_8, outVal&0x08);
    PLIB_PORTS_PinWrite (PORTS_ID_0, PORT_CHANNEL_A, PORTS_BIT_POS_10, outVal&0x10);
    PLIB_PORTS_PinWrite (PORTS_ID_0, PORT_CHANNEL_D, PORTS_BIT_POS_8, outVal&0x20);
    PLIB_PORTS_PinWrite (PORTS_ID_0, PORT_CHANNEL_D, PORTS_BIT_POS_11, outVal&0x40);
    PLIB_PORTS_PinWrite (PORTS_ID_0, PORT_CHANNEL_D, PORTS_BIT_POS_6, outVal&0x80);
    
}

void dbgOutputEvent(unsigned int outVal){
    PLIB_PORTS_Write (PORTS_ID_0, PORT_CHANNEL_E, outVal);
}

void stopBadError(){
    dbgOutputEvent(ERR_HANDLER_CALLED);
    
    PLIB_INT_Disable(INT_ID_0);
        
    vTaskSuspendAll();
    
    while(1);
}