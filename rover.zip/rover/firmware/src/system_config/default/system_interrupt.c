#include "system/common/sys_common.h"
#include "main_thread.h"
#include "sensor_thread.h"
#include "motor_thread.h"
#include "system_definitions.h"
#include "debug.h"
#include "sensor_queue.h"

// *****************************************************************************
// *****************************************************************************
// Section: System Interrupt Vector Functions
// *****************************************************************************
// *****************************************************************************


void IntHandlerDrvI2CInstance0(void)
{
	DRV_I2C0_Tasks();
 
}
     
 
   

void IntHandlerDrvI2CInstance1(void)
{
	DRV_I2C1_Tasks();
 
}
     
 
   
 
 

 

int bufflength = 9;
uint8_t readbuff[9];
int buffptr = 0;

 void IntHandlerDrvUsartInstance0(void)
{
    dbgOutputEvent(UART_ISR_START);

    /* Reading the transmit interrupt flag */
    if(SYS_INT_SourceStatusGet(INT_SOURCE_USART_1_TRANSMIT))
    {   
        if(uxQueueMessagesWaitingFromISR(txMQ) == 0){
            /* Disable the interrupt, to avoid calling ISR continuously*/
            SYS_INT_SourceDisable(INT_SOURCE_USART_1_TRANSMIT);
        }
        else{
            uint8_t b;
            readFromTXQueue(&b);
            /* Send one byte */
            PLIB_USART_TransmitterByteSend(USART_ID_1, b);
        }
    }
    
    DRV_USART_TasksError(sysObj.drvUsart0);
    
        /* Reading the receive interrupt flag */
    if(SYS_INT_SourceStatusGet(INT_SOURCE_USART_1_RECEIVE))
    {      
        uint8_t byte = PLIB_USART_ReceiverByteReceive(USART_ID_1);
        dbgOutputVal(byte);
        readbuff[buffptr] = byte;
        buffptr = buffptr + 1;
        
        if(buffptr == bufflength){
            if(readbuff[0] == 't' && readbuff[1] == 'y' && readbuff[2] == 'p' 
                    && readbuff[3] == 'e' && readbuff[4] == ':'){
                struct MsgData msg;
                msg.label = readbuff[5];
                writeToDataQueue(&msg);
            }
        }
    }
    
    
    /* Clear up the interrupt flag */
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_1_TRANSMIT);
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_1_RECEIVE);
 
    dbgOutputEvent(UART_ISR_STOP);
}
 
 
 

 

 

 

 

 
 
 

void IntHandlerDrvTmrInstance0(void)
{
    DRV_TMR_Tasks(sysObj.drvTmr0);
}
 
/*******************************************************************************
 End of File
*/
