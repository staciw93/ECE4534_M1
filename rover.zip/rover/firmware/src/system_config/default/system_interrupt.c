#include "system/common/sys_common.h"
#include "main_thread.h"
#include "sensor_thread.h"
#include "motor_thread.h"
#include "system_definitions.h"
#include "debug.h"
#include "sensor_queue.h"

// *****************************************************************************
// *****************************************************************************
// Section: System Interrupt Vector Functions
// *****************************************************************************
// *****************************************************************************


void IntHandlerDrvI2CInstance0(void)
{
	DRV_I2C0_Tasks();
 
}
     
 
   

void IntHandlerDrvI2CInstance1(void)
{
	DRV_I2C1_Tasks();
 
}
     
 
   
 
 

 

int bufflength = 9;
uint8_t readbuff[9];
int buffptr = 0;

 void IntHandlerDrvUsartInstance0(void)
{
    dbgOutputEvent(UART_ISR_START);

    /* Reading the transmit interrupt flag */
    if(SYS_INT_SourceStatusGet(INT_SOURCE_USART_1_TRANSMIT))
    {   
        if(uxQueueMessagesWaitingFromISR(txMQ) == 0){
            /* Disable the interrupt, to avoid calling ISR continuously*/
            SYS_INT_SourceDisable(INT_SOURCE_USART_1_TRANSMIT);
        }
        else{
            uint8_t b;
            readFromTXQueue(&b);
            /* Send one byte */
            PLIB_USART_TransmitterByteSend(USART_ID_1, b);
        }
    }
    
    DRV_USART_TasksError(sysObj.drvUsart0);
    
        /* Reading the receive interrupt flag */
    if(SYS_INT_SourceStatusGet(INT_SOURCE_USART_1_RECEIVE))
    {      
        uint8_t byte = PLIB_USART_ReceiverByteReceive(USART_ID_1);
        dbgOutputVal(byte);
        readbuff[buffptr] = byte;
        buffptr = buffptr + 1;
        
        if(buffptr == bufflength){
            if(readbuff[0] == 't' && readbuff[1] == 'y' && readbuff[2] == 'p' 
                    && readbuff[3] == 'e' && readbuff[4] == ':'){
                struct MsgData msg;
                msg.label = readbuff[5];
                writeToDataQueue(&msg);
            }
        }
    }
    
    
    /* Clear up the interrupt flag */
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_1_TRANSMIT);
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_1_RECEIVE);
 
    dbgOutputEvent(UART_ISR_STOP);
}
 
 
 

//Read encoder values and do the math for revolutions per second

 void ReadMotorValues(BaseType_t * pxHigherPriorityTaskWoken){
    //read motor encoder values, reset timer, process values, send message
   //dbgOutputEvent(100); 
   uint32_t timer4val = DRV_TMR1_CounterValueGet();
   uint32_t timer4val2 = DRV_TMR2_CounterValueGet();
   dbgOutputEvent(timer4val);
   dbgOutputEvent(timer4val2);
   //uint32_t four = 4;
   uint32_t RevsPerSec = 100*(4*timer4val)/(0.1*298*12);
   uint32_t RevsPerSec2 = 100*(4*timer4val2)/(0.1*298*12);
   dbgOutputEvent(RevsPerSec);
   dbgOutputEvent(RevsPerSec2);
   DRV_TMR1_CounterClear();
   DRV_TMR2_CounterClear();
}

 

void IntHandlerDrvTmrInstance0(void)
{
    //dbgOutputEvent(ENTER_ISR);
    BaseType_t pxHigherPriorityTaskWoken=pdFALSE;
     
    //while(!DRV_ADC_SamplesAvailable()){}
    //dbgOutputEvent(START_ADC_READ);
    //DRV_ADC_Start();
    //uint32_t sample = DRV_ADC_SamplesRead(0);
    //DRV_ADC_Stop();
    //dbgOutputEvent(STOP_ADC_READ);
    
    //added portion for motor testing
    //uint32_t sample = 1;
    
    //MSGTYPE msg = sample;
    
    //writeToQueue(&msg);
    
    ReadMotorValues(&pxHigherPriorityTaskWoken);
    //writeToQueue(&msg);
    
    PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_5);
    
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
    //dbgOutputEvent(EXIT_ISR);
    //DRV_TMR_Tasks(sysObj.drvTmr0);
}
void IntHandlerDrvTmrInstance1(void)
{
    PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_4);
}
void IntHandlerDrvTmrInstance2(void)
{
    PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_3);
}
void IntHandlerDrvTmrInstance3(void)
{
    PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_2);
}
 
/*******************************************************************************
 End of File
*/
