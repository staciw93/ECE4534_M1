#ifndef _SENSOR_QUEUE_H    /* Guard against multiple inclusion */
#define _SENSOR_QUEUE_H

#include "FreeRTOS.h"
#include "queue.h"
#include "debug.h"

/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif


#define MSGQUEUE_LENGTH                   30
    
enum Type {ERROR, MSG_REC, STATUS, SENSOR, MOTOR};

struct MsgData{
    enum Type label;
    char message[20];
};

QueueHandle_t motorMQ;
QueueHandle_t dataMQ;
QueueHandle_t sensorMQ;
QueueHandle_t txMQ;
    
    void createQueues();
    
    void readFromMotorQueue(void* msg);
    void readFromDataQueue(void* msg);
    void readFromSensorQueue(void* msg);
    void readFromTXQueue(void* msg);
    
    void writeToMotorQueue(void* msg);
    void writeToMotorQueueFromISR(void* msg);
    void writeToDataQueue(void* msg);
    void writeToSensorQueue(void* msg);
    void writeToTXQueue(void* msg);
    void writeToTXQueueFromISR(void* msg);





    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
