#include "sensor_state.h"
#include "debug.h"


unsigned int avgStateMachine(unsigned int sumOfReadings, unsigned int curReading, unsigned int stateNum){
    unsigned int sum = 0;
    
    switch(stateNum){
        case 0:
        {
            dbgOutputEvent(ENTER_STATE_0);
            dbgOutputVal(curReading);
            sum = curReading;
            break;
        }
        case 1:
        {
            dbgOutputEvent(ENTER_STATE_1);
            dbgOutputVal(curReading);
            sum = sumOfReadings + curReading;
            break;
        }
        case 2:
        {
            dbgOutputEvent(ENTER_STATE_2);
            dbgOutputVal(curReading);
            sum = sumOfReadings + curReading;
            break;
        }
        case 3:
        {
            dbgOutputEvent(ENTER_STATE_3);
            dbgOutputVal(curReading);
            sum = sumOfReadings + curReading;
            sum = sum >> 2;
            dbgUARTVal(sum);
            break;
        }
        default:
        {
            dbgOutputEvent(ERR_IN_DEFAULT_STATE);
            stopBadError();
        }
    }
    
    return sum;
}