/*******************************************************************************
 System Interrupts File

  File Name:
    system_interrupt.c

  Summary:
    Raw ISR definitions.

  Description:
    This file contains a definitions of the raw ISRs required to support the
    interrupt sub-system.

  Summary:
    This file contains source code for the interrupt vector functions in the
    system.

  Description:
    This file contains source code for the interrupt vector functions in the
    system.  It implements the system and part specific vector "stub" functions
    from which the individual "Tasks" functions are called for any modules
    executing interrupt-driven in the MPLAB Harmony system.

  Remarks:
    This file requires access to the systemObjects global data structure that
    contains the object handles to all MPLAB Harmony module objects executing
    interrupt-driven in the system.  These handles are passed into the individual
    module "Tasks" functions to identify the instance of the module to maintain.
 *******************************************************************************/

#include "system/common/sys_common.h"
#include "app.h"
#include "system_definitions.h"
#include "debug.h"
#include "sensor_queue.h"

// *****************************************************************************
// *****************************************************************************
// Section: System Interrupt Vector Functions
// *****************************************************************************
// *****************************************************************************
void ReadMotorValues(BaseType_t * pxHigherPriorityTaskWoken){
    //read motor encoder values, reset timer, process values, send message
   //dbgOutputEvent(100); 
   uint32_t timer4val = DRV_TMR1_CounterValueGet();
   dbgOutputEvent(timer4val);
   //uint32_t four = 4;
   uint32_t RevsPerSec = 100*(4*timer4val)/(0.1*298*12);
   dbgOutputEvent(RevsPerSec);
   DRV_TMR1_CounterClear();
}
 


void IntHandlerDrvTmrInstance0(void)
{
    dbgOutputEvent(ENTER_ISR);
    BaseType_t pxHigherPriorityTaskWoken=pdFALSE;
     
    //while(!DRV_ADC_SamplesAvailable()){}
    //dbgOutputEvent(START_ADC_READ);
    //DRV_ADC_Start();
    //uint32_t sample = DRV_ADC_SamplesRead(0);
    //DRV_ADC_Stop();
    //dbgOutputEvent(STOP_ADC_READ);
    
    //added portion for motor testing
    uint32_t sample = 1;
    
    MSGTYPE msg = sample;
    
    //writeToQueue(&msg);
    
    ReadMotorValues(&pxHigherPriorityTaskWoken);
    writeToQueue(&msg);
    
    PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_5);
    
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
    dbgOutputEvent(EXIT_ISR);
}
void IntHandlerDrvTmrInstance1(void)
{
    PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_4);
}
void IntHandlerDrvTmrInstance2(void)
{
    PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_3);
}
void IntHandlerDrvTmrInstance3(void)
{
    PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_2);
}
    
    

 /*******************************************************************************
 End of File
*/
