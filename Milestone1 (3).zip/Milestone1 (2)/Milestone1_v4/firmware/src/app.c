#include "app.h"
#include "debug.h"
#include "sensor_state.h"
#include "sensor_queue.h"

/*******************************************************************************
  Function:
    void APP_Initialize ( void )

  Remarks:
    See prototype in app.h.
 */

void Motor1Control(){
    DRV_OC0_PulseWidthSet(7000);
    PLIB_PORTS_PinClear(0, 0x02, 14);
    
}
void Motor2Control(){
    DRV_OC1_PulseWidthSet(7000);
    PLIB_PORTS_PinClear(0, 0x06, 1);
    
}

void APP_Initialize ( void )
{
    dbgOutputEvent(APP_TASK_INIT);
    
    /* Set up GPIO ports */
    PLIB_PORTS_DirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_E, 0x00FF);
    //PLIB_PORTS_DirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_D, 0x00FF);
    
    /* Set up ADC */
    //DRV_ADC_Close();
    //DRV_ADC_Initialize();
    //DRV_ADC_Open();
            
    /* Set up Timer */
    DRV_TMR0_Start();
    DRV_TMR1_Start();
    DRV_TMR3_Start();
    DRV_TMR2_Start();
    
    /* Set up the OCs */
    DRV_OC0_Enable();
    DRV_OC1_Enable();
    DRV_OC0_Start();
    DRV_OC1_Start();
    //DRV_OC0_PulseWidthSet(12500);
    //DRV_OC1_PulseWidthSet(12500);
    
    /* Create Message Queue*/
    createQueue();
}


/******************************************************************************
  Function:
    void APP_Tasks ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_Tasks ( void )
{
    dbgOutputEvent(APP_TASK_START);
    unsigned int state = 0;
    unsigned int curSum = 0;
    unsigned int nxtSum = 0;
    unsigned int count = 0;
    //DRV_OC0_PulseWidthSet(12500);
    //DRV_OC1_PulseWidthSet(12500);
    Motor1Control();
    Motor2Control();
    
    while(1){
        MSGTYPE msg;
        dbgOutputEvent(5);
        readFromQueue(&msg);
        dbgOutputEvent(6);
        //DRV_OC0_PulseWidthSet(7000);
        //DRV_OC1_PulseWidthSet(7000);
//        nxtSum = avgStateMachine(curSum, msg, state);
//        
//        if(state >= 3)
//            state = 0; 
//        else
//            state = state + 1;
//        
//        curSum = nxtSum;
//        count = count + 1;
//        if(count == 4)
//            state = 4;
//        
    }
    
}

 

/*******************************************************************************
 End of File
 */
