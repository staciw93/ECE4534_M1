#include "sensor_thread.h"
#include "debug.h"
#include "sensor_queue.h"

/*******************************************************************************
  Function:
    void SENSOR_THREAD_Initialize ( void )

  Remarks:
    See prototype in sensor_thread.h.
 */

void SENSOR_THREAD_Initialize ( void )
{
    dbgOutputEvent(SENSOR_THREAD_INIT);
    sensorState = SEND_TO_SENSOR_Q;
}


/******************************************************************************
  Function:
    void SENSOR_THREAD_Tasks ( void )

  Remarks:
    See prototype in sensor_thread.h.
 */

void SENSOR_THREAD_Tasks ( void )
{
    dbgOutputEvent(SENSOR_THREAD_START);
    
    struct MsgData m;
    
    /* Check the application's current state. */
    switch ( sensorState )
    {
        case SEND_TO_SENSOR_Q:{
            if(m.label != MOTOR)
                m.label = SENSOR;
            writeToSensorQueue(&m);
            dbgOutputEvent(SENT_MSG_TO_SENSOR_Q);
            sensorState = REC_FROM_DATA_Q;
            break;
        }
        case REC_FROM_DATA_Q:{
            if(uxQueueMessagesWaiting(dataMQ) != 0){
                readFromDataQueue(&m);
                dbgOutputEvent(REC_MSG_FROM_DATA_Q);
                dbgOutputVal(m.label);
                if(m.label == MSG_REC)
                    sensorState = STOP_SENSOR;
                else if(m.label == MOTOR)
                    sensorState = SEND_TO_SENSOR_Q;
            }
            break;
        }
        case STOP_SENSOR:{
            break;
        }
        default:{
            break;
        }
    }
}

 

/*******************************************************************************
 End of File
 */
