#include "main_thread.h"
#include "debug.h"
#include "sensor_queue.h"

//motor initialization functions
void Motor1Control(){
    DRV_OC0_PulseWidthSet(12000);
    //PLIB_PORTS_PinClear(PORTS_ID_0, PORT_CHANNEL_C, PORTS_BIT_POS_14);
    PLIB_PORTS_PinSet(PORTS_ID_0, PORT_CHANNEL_C, PORTS_BIT_POS_14);
   
    
}
void Motor2Control(){
    DRV_OC1_PulseWidthSet(12000);
    PLIB_PORTS_PinClear(PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_1);
    //PLIB_PORTS_PinSet(PORTS_ID_0, PORT_CHANNEL_G, PORTS_BIT_POS_1);
    
}

/*******************************************************************************
  Function:
    void MAIN_THREAD_Initialize ( void )

  Remarks:
    See prototype in main_thread.h.
 */

void MAIN_THREAD_Initialize ( void )
{
    dbgOutputEvent(MAIN_THREAD_INIT);
    
    /* Set up GPIO port for debugging */
    PLIB_PORTS_DirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_E, 0x00FF);
    PLIB_PORTS_DirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_B, 0x3800);
    PLIB_PORTS_DirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_G, 0x0100);
    PLIB_PORTS_DirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_A, 0x0400);
    PLIB_PORTS_DirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_D, 0x0940);
    
    /* Create the message queues */
    createQueues();
    
    mainState = REC_FROM_SENSOR_Q;
    
    /* Set up Timer */
    DRV_TMR0_Start();
    DRV_TMR1_Start();
    DRV_TMR3_Start();
    DRV_TMR2_Start();
    
    /* Set up the OCs */
    DRV_OC0_Enable();
    DRV_OC1_Enable();
    DRV_OC0_Start();
    DRV_OC1_Start();
    
    //initialize the motors
    Motor1Control();
    Motor2Control();
}

void sendMsgToTXISR(struct MsgData msg){
    writeToTXQueue("s");
    writeToTXQueue("e");
    writeToTXQueue("n");
    writeToTXQueue("t");
    writeToTXQueue(":");
    writeToTXQueue("R");
    // write message to queue
    writeToTXQueue("t");
    writeToTXQueue("y");
    writeToTXQueue("p");
    writeToTXQueue("e");
    writeToTXQueue(":");
    
    uint8_t val = msg.label;
    writeToTXQueue(&val);
    
    writeToTXQueue("f");
    writeToTXQueue("i");
    writeToTXQueue("n");
    
    // enable transmit interrupts
    SYS_INT_SourceEnable(INT_SOURCE_USART_1_TRANSMIT);
}

/******************************************************************************
  Function:
    void MAIN_THREAD_Tasks ( void )

  Remarks:
    See prototype in main_thread.h.
 */

void MAIN_THREAD_Tasks ( void )
{
    dbgOutputEvent(MAIN_THREAD_START);
    
    struct MsgData mr;
    
    /* Check the application's current state. */
    switch ( mainState )
    {
        case REC_FROM_SENSOR_Q:{
            if(uxQueueMessagesWaiting(sensorMQ) != 0){
                readFromSensorQueue(&mr);
                dbgOutputEvent(REC_MSG_FROM_SENSOR_Q);
                dbgOutputVal(mr.label);
                if(mr.label == SENSOR)
                    mainState = SEND_TO_TX_Q;
                else if(mr.label == MOTOR)
                    mainState = SEND_TO_MOTOR_Q;
            }
            break;
        }
        case SEND_TO_TX_Q:{
            sendMsgToTXISR(mr);
            dbgOutputEvent(SENT_MSG_TO_TX_Q);
            mainState = REC_FROM_SENSOR_Q;
            break;
        }
        case SEND_TO_MOTOR_Q:{
            writeToMotorQueue(&mr);
            dbgOutputEvent(SENT_MSG_TO_MOTOR_Q);
            mainState = REC_FROM_SENSOR_Q;
            break;
        }
        case STOP_MAIN:{
            break;
        }
        default:{
            break;
        }
    }
}

 

/*******************************************************************************
 End of File
 */
