#ifndef _SENSOR_QUEUE_H    /* Guard against multiple inclusion */
#define _SENSOR_QUEUE_H

#include "FreeRTOS.h"
#include "queue.h"
#include "debug.h"

/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif


#define MSGQUEUE_LENGTH                   30
    
enum Type {ERROR, MSG_REC, ROVER_DETECT, DELIVERY_REC, RESOURCE_GATHERED};

struct MsgData{
    enum Type label;
    char message[20];
};

QueueHandle_t stationaryData;
QueueHandle_t stationaryTX;
    
    void createQueues();
    void readFromStationaryDataQueue(void* msg);
    void readFromStationaryTXQueue(void* msg);
    void writeToStationaryDataQueue(void* msg);
    void writeToStationaryTXQueue(void* msg);





    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
