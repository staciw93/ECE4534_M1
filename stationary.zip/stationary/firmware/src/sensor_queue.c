#include "sensor_queue.h"

void createQueues(){
    stationaryData = xQueueCreate(MSGQUEUE_LENGTH, sizeof(struct MsgData));
    stationaryTX = xQueueCreate(MSGQUEUE_LENGTH, sizeof(struct MsgData));
    
    if(stationaryData == NULL){
        dbgOutputEvent(ERR_DATA_QUEUE_NOT_CREATED);
        stopBadError();
    }
    if(stationaryTX == NULL){
        dbgOutputEvent(ERR_TX_QUEUE_NOT_CREATED);
        stopBadError();
    }
}

void readFromStationaryDataQueue(void* msg){
    xQueueReceive(stationaryData, msg, portMAX_DELAY);
    dbgOutputEvent(MESSAGE_RECEIVE);
}

void readFromStationaryTXQueue(void* msg){
    xQueueReceiveFromISR(stationaryTX, msg, portMAX_DELAY);
    dbgOutputEvent(MESSAGE_RECEIVE);
}

void writeToStationaryDataQueue(void* msg){
        portBASE_TYPE pxHigherPriorityTaskWoken = pdFALSE;
    if(xQueueSendToBackFromISR(stationaryData, msg, &pxHigherPriorityTaskWoken) == pdPASS)
        dbgOutputEvent(MESSAGE_WRITE_SUCCESS);
    else{
        dbgOutputEvent(ERR_MESSAGE_WRITE_FAIL);
        stopBadError();
    }
}
void writeToStationaryTXQueue(void* msg){
    portBASE_TYPE pxHigherPriorityTaskWoken = pdFALSE;
    if(xQueueSendToBack(stationaryTX, msg, &pxHigherPriorityTaskWoken) == pdPASS)
        dbgOutputEvent(MESSAGE_WRITE_SUCCESS);
    else{
        dbgOutputEvent(ERR_MESSAGE_WRITE_FAIL);
        stopBadError();
    }
}


/* *****************************************************************************
 End of File
 */
