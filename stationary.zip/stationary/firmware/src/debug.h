#ifndef _DEBUG_H    /* Guard against multiple inclusion */
#define _DEBUG_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "system_config.h"
#include "system_definitions.h"

/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif

    
#define APP_TASK_INIT               0x22
#define APP_TASK_START              0x23
    
#define UART_ISR_START              0x30
#define UART_ISR_TX_FLAG            0x31
#define UART_ISR_RX_FLAG            0x32
#define UART_ISR_STOP               0x33
#define UART_SENT_BYTE              0x34
#define UART_DISABLE_INT            0x35
    
#define SOFT_TIME_ADC_START         0x60
    
#define MESSAGE_WRITE_SUCCESS       0x50
#define MESSAGE_RECEIVE             0x51
    
#define ERR_TX_QUEUE_NOT_CREATED    0x40
#define ERR_DATA_QUEUE_NOT_CREATED    0x41
#define ERR_MESSAGE_WRITE_FAIL      0x42
#define ERR_HANDLER_CALLED          0x43

void dbgOutputVal(uint8_t outVal);
void dbgOutputEvent(unsigned int outVal);
void stopBadError();

    

    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
