#include "system/common/sys_common.h"
#include "app.h"
#include "system_definitions.h"
#include "sensor_queue.h"
#include "debug.h"

// *****************************************************************************
// *****************************************************************************
// Section: System Interrupt Vector Functions
// *****************************************************************************
// *****************************************************************************

int bufflength = 9;
uint8_t readbuff[9];
int buffptr = 0;

void IntHandlerDrvUsartInstance0(void)
{
    dbgOutputEvent(UART_ISR_START);

    /* Reading the transmit interrupt flag */
    if(SYS_INT_SourceStatusGet(INT_SOURCE_USART_1_TRANSMIT))
    {
        
        dbgOutputEvent(UART_ISR_TX_FLAG); 
    
        if(uxQueueMessagesWaitingFromISR(stationaryTX) == 0){
            /* Disable the interrupt, to avoid calling ISR continuously*/
            SYS_INT_SourceDisable(INT_SOURCE_USART_1_TRANSMIT);
            dbgOutputEvent(UART_DISABLE_INT); 
        }
        else{
            uint8_t b;
            readFromStationaryTXQueue(&b);
            /* Send one byte */
            PLIB_USART_TransmitterByteSend(USART_ID_1, b);
            dbgOutputVal(b);
            dbgOutputEvent(UART_SENT_BYTE); 
        }
    }
    
    DRV_USART_TasksError(sysObj.drvUsart0);
    
        /* Reading the receive interrupt flag */
    if(SYS_INT_SourceStatusGet(INT_SOURCE_USART_1_RECEIVE))
    {
        dbgOutputEvent(UART_ISR_RX_FLAG);
      
        uint8_t byte = PLIB_USART_ReceiverByteReceive(USART_ID_1);
        dbgOutputVal(byte);
        readbuff[buffptr] = byte;
        buffptr = buffptr + 1;
        
        if(buffptr == bufflength){
            if(readbuff[0] == 't' && readbuff[1] == 'y' && readbuff[2] == 'p' 
                    && readbuff[3] == 'e' && readbuff[4] == ':'){
                struct MsgData msg;
                msg.label = readbuff[5];
                writeToStationaryDataQueue(&msg);
            }
        }
    }
    
    
    /* Clear up the interrupt flag */
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_1_TRANSMIT);
    PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_1_RECEIVE);
 
    dbgOutputEvent(UART_ISR_STOP);
}
 
 
 

 

 

 

 

 
 
 
/*******************************************************************************
 End of File
*/
