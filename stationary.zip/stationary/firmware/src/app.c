#include "app.h"
#include "debug.h"
#include "sensor_queue.h"

/* ADC SOFTWARE TIMER ISR */
void ADCTimerCallBack(TimerHandle_t xTimer)
{
    dbgOutputEvent(SOFT_TIME_ADC_START);
    portBASE_TYPE pxHigherPriorityTaskWoken = pdFALSE;
    struct MsgData m;
    m.label = ROVER_DETECT;
    writeToStationaryDataQueue(&m);
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
}

/*******************************************************************************
  Function:
    void APP_Initialize ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_Initialize ( void )
{
    dbgOutputEvent(APP_TASK_INIT);
    
    /* Set up GPIO port for debugging */
    PLIB_PORTS_DirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_E, 0x00FF);
    PLIB_PORTS_DirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_B, 0x3800);
    PLIB_PORTS_DirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_G, 0x0100);
    PLIB_PORTS_DirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_A, 0x0400);
    PLIB_PORTS_DirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_D, 0x0940);
    
    /* Create the message queues */
    createQueues();
    
    timer = xTimerCreate("timer", 
                        pdMS_TO_TICKS(500),
                        pdTRUE,
                        (void *) 0,
                        ADCTimerCallBack);
}

void sendMsgToTXISR(struct MsgData msg){
    writeToStationaryTXQueue("s");
    writeToStationaryTXQueue("e");
    writeToStationaryTXQueue("n");
    writeToStationaryTXQueue("t");
    writeToStationaryTXQueue(":");
    writeToStationaryTXQueue("S");
    // write message to queue
    writeToStationaryTXQueue("t");
    writeToStationaryTXQueue("y");
    writeToStationaryTXQueue("p");
    writeToStationaryTXQueue("e");
    writeToStationaryTXQueue(":");
    
    uint8_t val = msg.label;
    writeToStationaryTXQueue(&val);
    
    writeToStationaryTXQueue("f");
    writeToStationaryTXQueue("i");
    writeToStationaryTXQueue("n");
    
    // enable transmit interrupts
    SYS_INT_SourceEnable(INT_SOURCE_USART_1_TRANSMIT);
}


/******************************************************************************
  Function:
    void APP_Tasks ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_Tasks ( void )
{
    dbgOutputEvent(APP_TASK_START);
    
    xTimerStart(timer, 0);
  
    /*
    struct MsgData msg;
    msg.label = DELIVERY_REC;
    sendMsgToTXISR(msg);
     */
    
    struct MsgData mr;
   
    while(1){
        readFromStationaryDataQueue(&mr);
        if(mr.label == MSG_REC)
            dbgOutputEvent(MESSAGE_RECEIVE);
        else if(mr.label == ROVER_DETECT)
            sendMsgToTXISR(mr);
    }
}

 

/*******************************************************************************
 End of File
 */
