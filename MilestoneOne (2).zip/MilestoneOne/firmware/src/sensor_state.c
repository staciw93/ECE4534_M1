////////////////////////////////////////////////////////////////////////////////
// Embedded Team 18
// Author(s):   Dow Perkins, Brad Finagin
// Date:        1/25/18
// Description: This file is contains our sensor state machine and manipulation
// implementation.
////////////////////////////////////////////////////////////////////////////////

#include "sensor_state.h"

void sensorAvgFSM(unsigned int inVal, unsigned int * accum, ACQ_STATE * state){
    unsigned char arr[3];
    
    switch(*state){
        case ACQ1:
            *accum = inVal;
            dbgOutputVal(inVal);
            dbgOutputLoc(STATE_1);
            *state = ACQ2;
            break;
        case ACQ2:
            *accum = *accum + inVal;
            dbgOutputVal(inVal);
            dbgOutputLoc(STATE_2);
            *state = ACQ3;
            break;
        case ACQ3:
            *accum = *accum + inVal;
            dbgOutputVal(inVal);
            dbgOutputLoc(STATE_3);
            *state = ACQ4;
            break;
        case ACQ4:
            *accum = *accum + inVal;
            *accum = *accum / 4;
            dbgOutputVal(*accum);
            dbgOutputLoc(STATE_4);
            convertValueToAscii(*accum, arr);
            dbgUARTVal(arr[2]);
            dbgUARTVal(arr[1]);
            dbgUARTVal(arr[0]);
            dbgUARTVal('c');
            dbgUARTVal('m');
            *state = ACQ1;
            *accum = 0;
            break;
        default:
            dbgStopAll(FAILURE); //change hardcode to output LOC macro
            break;
    }
}