#include "sensor_thread.h"
#include "debug.h"
#include "sensor_queue.h"

/* RGB SOFTWARE TIMER ISR */
void RGBTimerCallBack(TimerHandle_t xTimer)
{
    dbgOutputEvent(RGB_ISR_START);
    portBASE_TYPE pxHigherPriorityTaskWoken = pdFALSE;
    struct MsgData m;
    m.label = RGB;
    writeToDataQueue(&m);
    dbgOutputEvent(SENT_MSG_TO_DATA_Q);
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
    dbgOutputEvent(RGB_ISR_STOP);
}

/* LINE SENSOR SOFTWARE TIMER ISR */
void LineTimerCallBack(TimerHandle_t xTimer)
{
    dbgOutputEvent(LINE_ISR_START);
    portBASE_TYPE pxHigherPriorityTaskWoken = pdFALSE;
    struct MsgData m;
    m.label = LINE;
    writeToDataQueue(&m);
    dbgOutputEvent(SENT_MSG_TO_DATA_Q);
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
    dbgOutputEvent(LINE_ISR_STOP);
}

/*******************************************************************************
  Function:
    void SENSOR_THREAD_Initialize ( void )

  Remarks:
    See prototype in sensor_thread.h.
 */

void SENSOR_THREAD_Initialize ( void )
{
    sensorState = REC_FROM_DATA_Q;
    
    rgbTimer = xTimerCreate("rgbTimer", 
                        pdMS_TO_TICKS(500),
                        pdTRUE,
                        (void *) 0,
                        RGBTimerCallBack);
    
    lineTimer = xTimerCreate("lineTimer", 
                        pdMS_TO_TICKS(200),
                        pdTRUE,
                        (void *) 0,
                        LineTimerCallBack);
    
    xTimerStart(lineTimer, 0);
    xTimerStart(rgbTimer, 0);
}


/******************************************************************************
  Function:
    void SENSOR_THREAD_Tasks ( void )

  Remarks:
    See prototype in sensor_thread.h.
 */

void SENSOR_THREAD_Tasks ( void )
{   
    struct MsgData m;
    
    /* Check the application's current state. */
    switch ( sensorState )
    {
        case SEND_TO_SENSOR_Q:{
            if(m.label == DIRECTION){
                //do something
            }
            else if(m.label == LINE){
                //do something
            }
            else if(m.label == RGB){
                //do something
            }
            else{
                m.label = ERROR;
                sensorState = STOP_SENSOR;
            }
            writeToSensorQueue(&m);
            dbgOutputEvent(SENT_MSG_TO_SENSOR_Q);
            sensorState = REC_FROM_DATA_Q;
            break;
        }
        case REC_FROM_DATA_Q:{
            if(uxQueueMessagesWaiting(dataMQ) != 0){
                readFromDataQueue(&m);
                dbgOutputEvent(REC_MSG_FROM_DATA_Q);
                dbgOutputVal(m.label);
                if(m.label == DIRECTION){
                    //do something
                }
                else if(m.label == LINE){
                    //do something
                }
                else if(m.label == RGB){
                    //do something
                }
                else{
                    m.label = ERROR;
                }
                sensorState = SEND_TO_SENSOR_Q;
            }
            break;
        }
        case STOP_SENSOR:{
            break;
        }
        default:{
            break;
        }
    }
}

 

/*******************************************************************************
 End of File
 */
