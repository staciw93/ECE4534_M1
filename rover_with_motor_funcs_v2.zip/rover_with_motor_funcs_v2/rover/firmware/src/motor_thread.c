#include "motor_thread.h"
#include "debug.h"
#include "sensor_queue.h"

/* ENCODER SOFTWARE TIMER ISR */
void EncoderTimerCallBack(TimerHandle_t xTimer)
{
    dbgOutputEvent(ENCODER_ISR_START);
    portBASE_TYPE pxHigherPriorityTaskWoken = pdFALSE;
    struct MsgData m;
    m.label = ENCODER;
    writeToSensorQueueFromISR(&m);
    dbgOutputEvent(SENT_MSG_TO_TX_Q);
    writeToMotorQueueFromISR(&m);
    dbgOutputEvent(SENT_MSG_TO_MOTOR_Q);
    portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);
    dbgOutputEvent(ENCODER_ISR_STOP);
}

/*******************************************************************************
  Function:
    void MOTOR_THREAD_Initialize ( void )

  Remarks:
    See prototype in motor_thread.h.
 */

void MOTOR_THREAD_Initialize ( void )
{
    motorState = SEND_TO_SEN_Q;
    
    encoderTimer = xTimerCreate("encoderTimer", 
                        pdMS_TO_TICKS(300),
                        pdTRUE,
                        (void *) 0,
                        EncoderTimerCallBack);
    
    xTimerStart(encoderTimer, 0);
}


/******************************************************************************
  Function:
    void MOTOR_THREAD_Tasks ( void )

  Remarks:
    See prototype in motor_thread.h.
 */

void MOTOR_THREAD_Tasks ( void )
{   
    struct MsgData m;
    
    /* Check the application's current state. */
    switch ( motorState )
    {
        //sends a request to server for direction
        case SEND_TO_SEN_Q:{
            m.req = GET;
            m.label = DIRECTION;
            writeToSensorQueue(&m);
            motorState = REC_FROM_MOTOR_Q;
            break;
        }
        case REC_FROM_MOTOR_Q:{
            if(uxQueueMessagesWaiting(motorMQ) != 0){
                readFromMotorQueue(&m);
                dbgOutputEvent(REC_MSG_FROM_MOTOR_Q);
                dbgOutputVal(m.label);
                if(m.label == ENCODER){
                    //do something
                }
                else if(m.label == DIRECTION){
                    //do something
                }
                else if(m.label == LINE){
                    //do something
                }
                else{
                    motorState = STOP_MOTOR;
                }
            }
            break;
        }
        case STOP_MOTOR:{
            break;
        }
        default:{
            break;
        }
    }
}

 

/*******************************************************************************
 End of File
 */
