#include "sensor_queue.h"

void createQueues(){
    motorMQ = xQueueCreate(MSGQUEUE_LENGTH, sizeof(struct MsgData));
    dataMQ = xQueueCreate(MSGQUEUE_LENGTH, sizeof(struct MsgData));
    sensorMQ = xQueueCreate(MSGQUEUE_LENGTH, sizeof(struct MsgData));
    txMQ = xQueueCreate(MSGQUEUE_LENGTH, sizeof(struct MsgData));
    
    if(motorMQ == NULL){
        dbgOutputEvent(ERR_MOTOR_QUEUE_NOT_CREATED);
        stopBadError();
    }
    if(dataMQ == NULL){
        dbgOutputEvent(ERR_DATA_QUEUE_NOT_CREATED);
        stopBadError();
    }
    if(sensorMQ == NULL){
        dbgOutputEvent(ERR_SENSOR_QUEUE_NOT_CREATED);
        stopBadError();
    }
    if(txMQ == NULL){
        dbgOutputEvent(ERR_TX_QUEUE_NOT_CREATED);
        stopBadError();
    }
}

void readFromMotorQueue(void* msg){
    xQueueReceive(motorMQ, msg, portMAX_DELAY);
    dbgOutputEvent(MESSAGE_RECEIVE);
}
void readFromDataQueue(void* msg){
    xQueueReceive(dataMQ, msg, portMAX_DELAY);
    dbgOutputEvent(MESSAGE_RECEIVE);
}
void readFromSensorQueue(void* msg){
    xQueueReceive(sensorMQ, msg, portMAX_DELAY);
    dbgOutputEvent(MESSAGE_RECEIVE);
}
void readFromTXQueue(void* msg){
    xQueueReceiveFromISR(txMQ, msg, portMAX_DELAY);
    dbgOutputEvent(MESSAGE_RECEIVE);
}
    


void writeToMotorQueue(void* msg){
    portBASE_TYPE pxHigherPriorityTaskWoken = pdFALSE;
    if(xQueueSendToBack(motorMQ, msg, &pxHigherPriorityTaskWoken) == pdPASS)
        dbgOutputEvent(MESSAGE_WRITE_SUCCESS);
    else{
        dbgOutputEvent(ERR_MESSAGE_WRITE_FAIL);
        stopBadError();
    }
}
void writeToMotorQueueFromISR(void* msg){
    portBASE_TYPE pxHigherPriorityTaskWoken = pdFALSE;
    if(xQueueSendToBackFromISR(motorMQ, msg, &pxHigherPriorityTaskWoken) == pdPASS)
        dbgOutputEvent(MESSAGE_WRITE_SUCCESS);
    else{
        dbgOutputEvent(ERR_MESSAGE_WRITE_FAIL);
        stopBadError();
    }
}
void writeToDataQueue(void* msg){
    portBASE_TYPE pxHigherPriorityTaskWoken = pdFALSE;
    if(xQueueSendToBackFromISR(dataMQ, msg, &pxHigherPriorityTaskWoken) == pdPASS)
        dbgOutputEvent(MESSAGE_WRITE_SUCCESS);
    else{
        dbgOutputEvent(ERR_MESSAGE_WRITE_FAIL);
        stopBadError();
    }
}
void writeToSensorQueue(void* msg){
    portBASE_TYPE pxHigherPriorityTaskWoken = pdFALSE;
    if(xQueueSendToBack(sensorMQ, msg, &pxHigherPriorityTaskWoken) == pdPASS)
        dbgOutputEvent(MESSAGE_WRITE_SUCCESS);
    else{
        dbgOutputEvent(ERR_MESSAGE_WRITE_FAIL);
        stopBadError();
    }
}
void writeToSensorQueueFromISR(void* msg){
    portBASE_TYPE pxHigherPriorityTaskWoken = pdFALSE;
    if(xQueueSendToBackFromISR(sensorMQ, msg, &pxHigherPriorityTaskWoken) == pdPASS){
        //dbgOutputEvent(MESSAGE_WRITE_SUCCESS);
    }
    else{
        //dbgOutputEvent(ERR_MESSAGE_WRITE_FAIL);
        stopBadError();
    }
}
void writeToTXQueue(void* msg){
    portBASE_TYPE pxHigherPriorityTaskWoken = pdFALSE;
    if(xQueueSendToBack(txMQ, msg, &pxHigherPriorityTaskWoken) == pdPASS)
        dbgOutputEvent(MESSAGE_WRITE_SUCCESS);
    else{
        dbgOutputEvent(ERR_MESSAGE_WRITE_FAIL);
        stopBadError();
    }
}
void writeToTXQueueFromISR(void* msg){
    portBASE_TYPE pxHigherPriorityTaskWoken = pdFALSE;
    if(xQueueSendToBackFromISR(txMQ, msg, &pxHigherPriorityTaskWoken) == pdPASS)
        dbgOutputEvent(MESSAGE_WRITE_SUCCESS);
    else{
        dbgOutputEvent(ERR_MESSAGE_WRITE_FAIL);
        stopBadError();
    }
}

/* *****************************************************************************
 End of File
 */
